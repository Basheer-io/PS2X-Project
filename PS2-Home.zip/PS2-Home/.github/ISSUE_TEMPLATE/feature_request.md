---
name: Feature request
about: Suggest an improvement
labels: enhancement
---
**Problem this solves**

**Proposed behavior**

**Alternatives considered**
